import logging
import argparse
import os
import json
import sys
from dotenv import load_dotenv
import os
from datetime import datetime
import pandas as pd
import numpy as np
import google.generativeai as genai
import uuid

from futures import create_leveraged_futures_order
from currency_info import get_historical_data_with_specific_indicators

RISK_REWARD_THRESHOLD = 1.5


def setup_logging(log_level=logging.INFO):
    """Set up logging configuration"""
    logger = logging.getLogger()
    logger.setLevel(log_level)

    # Create console handler with formatting
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    return logger


def load_api_config():
    """Load API configuration from .env file"""
    try:
        # Load environment variables from .env file
        load_dotenv()

        # Check for required environment variables
        required_keys = ["API_KEY", "API_SECRET", "HOST_USED"]
        missing_keys = [key for key in required_keys if os.getenv(key) is None]

        if missing_keys:
            raise KeyError(
                f"Missing required environment variables: {', '.join(missing_keys)}"
            )

        # Return configuration as dictionary
        return {
            "api_key": os.getenv("API_KEY"),
            "api_secret": os.getenv("API_SECRET"),
            "host_used": os.getenv("HOST_USED"),
            "gemini_api_key": os.getenv("GEMINI_API_KEY"),
        }

    except Exception as e:
        print(f"Error loading environment variables: {e}")
        sys.exit(1)


def fetch_market_data(
    logger, api_config, contract, settle="usdt", interval="15m", limit=100
):
    """Fetch market data with indicators and handle the response"""
    logger.info(f"Fetching {interval} data for {contract} with indicators...")

    result = get_historical_data_with_specific_indicators(
        logger=logger,
        api_key=api_config["api_key"],
        api_secret=api_config["api_secret"],
        host_used=api_config["host_used"],
        settle=settle,
        contract=contract,
        interval=interval,
        limit=limit,
    )

    if not result["success"]:
        logger.error(f"Failed to fetch data: {result.get('error', 'Unknown error')}")
        return None

    logger.info(f"Successfully fetched {len(result['data'])} candles for {contract}")
    return result["data"]


def fetch_multi_timeframe_data(
    logger, api_config, contract, settle="usdt", main_interval="15m", limit=100
):
    """Fetch data for multiple timeframes based on the main interval"""
    timeframe_data = {}

    # Define related timeframes based on main interval
    timeframe_map = {
        "5m": ["1m"],
        "15m": ["5m"],
        "1h": ["15m"],
        "4h": ["1h"],
        "1d": ["4h"],
    }

    # First fetch the main interval data
    main_data = fetch_market_data(
        logger, api_config, contract, settle, main_interval, limit
    )

    if main_data is not None:
        timeframe_data[main_interval] = main_data

        # Fetch related smaller timeframe if available
        if main_interval in timeframe_map:
            related_interval = timeframe_map[main_interval][0]
            related_limit = min(
                limit * 3, 300
            )  # Fetch more candles for smaller timeframes, but cap at 300

            logger.info(f"Fetching related {related_interval} data for {contract}...")
            related_data = fetch_market_data(
                logger, api_config, contract, settle, related_interval, related_limit
            )

            if related_data is not None:
                timeframe_data[related_interval] = related_data

    return timeframe_data


def format_float(value, precision=None, asset=None):
    """Format float values with proper precision based on asset type"""
    if value is None:
        return None

    # Convert numpy types to native Python types
    if isinstance(value, (np.floating, np.integer)):
        value = value.item()

    # Determine precision based on asset if not explicitly provided
    if precision is None and asset is not None:
        # Extract the base currency from the contract name (e.g., "BTC_USDT" -> "BTC")
        base_currency = asset.split("_")[0].upper() if "_" in asset else asset.upper()

        # Define precision based on asset type
        if base_currency in ["BTC", "ETH"]:
            precision = 1  # Major coins often use fewer decimal places
        elif base_currency in ["SOL", "ADA", "DOT", "LINK"]:
            precision = 2  # Mid-tier coins
        elif base_currency in ["XRP", "DOGE", "SHIB", "PEPE"]:
            precision = 5  # Lower-priced coins need more precision
        else:
            precision = 4  # Default precision for other assets

    # Use default precision if nothing else is specified
    precision = 2 if precision is None else precision

    # Apply rounding with the determined precision
    return round(value, precision)


def analyze_market_data(df, contract=None):
    """Analyze market data with improved accuracy and reliability"""
    if df is None or len(df) < 20:
        return "Not enough data for analysis"

    latest = df.iloc[-1]
    previous = df.iloc[-2]

    # Use more data points for trend analysis
    recent_candles = df.iloc[-10:].copy()

    # Calculate more robust price movement metrics
    price_change = latest["close"] - previous["close"]
    percent_change = (price_change / previous["close"]) * 100

    # Calculate price volatility (standard deviation of recent closes)
    volatility = recent_candles["close"].pct_change().std() * 100

    # Analyze RSI with better context
    rsi_signal = "Neutral"
    if latest["RSI"] > 70:
        rsi_signal = "Overbought"
    elif latest["RSI"] < 30:
        rsi_signal = "Oversold"

    # Add RSI trend (rising or falling)
    rsi_trend = "Stable"
    if latest["RSI"] > previous["RSI"]:
        rsi_trend = "Rising"
    elif latest["RSI"] < previous["RSI"]:
        rsi_trend = "Falling"

    # Analyze MACD with more detail
    macd_signal = "Neutral"
    if (
        latest["MACD_LINE"] > latest["MACD_SIGNAL"]
        and previous["MACD_LINE"] <= previous["MACD_SIGNAL"]
    ):
        macd_signal = "Bullish Crossover"
    elif (
        latest["MACD_LINE"] < latest["MACD_SIGNAL"]
        and previous["MACD_LINE"] >= previous["MACD_SIGNAL"]
    ):
        macd_signal = "Bearish Crossover"
    elif latest["MACD_LINE"] > latest["MACD_SIGNAL"]:
        macd_signal = "Bullish"
    elif latest["MACD_LINE"] < latest["MACD_SIGNAL"]:
        macd_signal = "Bearish"

    # Analyze MACD histogram trend
    macd_hist_trend = "Neutral"
    if latest["MACD_HIST"] > previous["MACD_HIST"]:
        macd_hist_trend = "Rising"
    elif latest["MACD_HIST"] < previous["MACD_HIST"]:
        macd_hist_trend = "Falling"

    # Analyze SAR with more clarity
    sar_signal = "Neutral"
    if latest["SAR_BULL"] is not None and previous["SAR_BULL"] is None:
        sar_signal = "Bullish Reversal"
    elif latest["SAR_BEAR"] is not None and previous["SAR_BEAR"] is None:
        sar_signal = "Bearish Reversal"
    elif latest["SAR_BULL"] is not None:
        sar_signal = "Bullish"
    elif latest["SAR_BEAR"] is not None:
        sar_signal = "Bearish"

    # Calculate volume trends
    volume_change = ((latest["volume"] / recent_candles["volume"].mean()) - 1) * 100
    volume_trend = "Normal"
    if volume_change > 50:
        volume_trend = "High"
    elif volume_change < -50:
        volume_trend = "Low"

    # Distance to support/resistance
    closest_support = None
    closest_resistance = None
    support_distance = float("inf")
    resistance_distance = float("inf")

    for i in range(1, 4):
        support_col = f"SUPPORT_{i}"
        resistance_col = f"RESISTANCE_{i}"

        if support_col in df.columns and not pd.isna(latest[support_col]):
            dist = latest["close"] - latest[support_col]
            if dist > 0 and dist < support_distance:
                support_distance = dist
                closest_support = latest[support_col]

        if resistance_col in df.columns and not pd.isna(latest[resistance_col]):
            dist = latest[resistance_col] - latest["close"]
            if dist > 0 and dist < resistance_distance:
                resistance_distance = dist
                closest_resistance = latest[resistance_col]

    # Support/resistance percentage distances
    support_percent = (
        (support_distance / latest["close"]) * 100 if closest_support else None
    )
    resistance_percent = (
        (resistance_distance / latest["close"]) * 100 if closest_resistance else None
    )

    # Generate enhanced summary with formatted values
    analysis = {
        "price": format_float(latest["close"], asset=contract),
        "change": f"{format_float(price_change, asset=contract)} ({format_float(percent_change, precision=2)}%)",
        "volatility": f"{format_float(volatility, precision=2)}%",
        "rsi": {
            "value": format_float(latest["RSI"], precision=2),
            "signal": rsi_signal,
            "trend": rsi_trend,
        },
        "macd": {
            "signal": macd_signal,
            "line": format_float(latest["MACD_LINE"], precision=2),
            "signal_line": format_float(latest["MACD_SIGNAL"], precision=2),
            "histogram": format_float(latest["MACD_HIST"], precision=2),
            "histogram_trend": macd_hist_trend,
        },
        "sar": {"signal": sar_signal},
        "supports": {
            "closest": format_float(closest_support, asset=contract),
            "distance": (
                format_float(support_distance, asset=contract)
                if closest_support
                else None
            ),
            "percent": (
                format_float(support_percent, precision=2) if support_percent else None
            ),
        },
        "resistances": {
            "closest": format_float(closest_resistance, asset=contract),
            "distance": (
                format_float(resistance_distance, asset=contract)
                if closest_resistance
                else None
            ),
            "percent": (
                format_float(resistance_percent, precision=2)
                if resistance_percent
                else None
            ),
        },
        "volume": {
            "current": format_float(latest["volume"], precision=0),
            "change": f"{format_float(volume_change, precision=2)}%",
            "trend": volume_trend,
        },
        "timestamp": latest["time"].strftime("%Y-%m-%d %H:%M:%S"),
    }

    return analysis


def save_data_to_csv(df, filename):
    """Save DataFrame to CSV file"""
    try:
        df.to_csv(filename, index=False)
        return True
    except Exception as e:
        print(f"Error saving data: {e}")
        return False


def format_market_data_for_llm(df, max_rows=5, contract=None):
    """Format market data in an LLM-friendly format"""
    if df is None or len(df) == 0:
        return "No market data available"

    # Get the most recent candles
    recent_data = df.iloc[-max_rows:].copy()

    # Format the data
    formatted_data = []
    for _, row in recent_data.iterrows():
        candle = {
            "time": row["time"].strftime("%Y-%m-%d %H:%M:%S"),
            "price": {
                "open": format_float(row["open"], asset=contract),
                "high": format_float(row["high"], asset=contract),
                "low": format_float(row["low"], asset=contract),
                "close": format_float(row["close"], asset=contract),
            },
            "volume": format_float(row["volume"], precision=0),
            "indicators": {
                "RSI": format_float(row.get("RSI"), precision=2),
                "MACD": {
                    "line": format_float(row.get("MACD_LINE"), precision=2),
                    "signal": format_float(row.get("MACD_SIGNAL"), precision=2),
                    "histogram": format_float(row.get("MACD_HIST"), precision=2),
                },
                "SAR": format_float(row.get("SAR"), asset=contract),
            },
        }

        # Add support/resistance if available
        supports = {}
        resistances = {}

        for i in range(1, 4):
            support_col = f"SUPPORT_{i}"
            resistance_col = f"RESISTANCE_{i}"

            if support_col in df.columns and not pd.isna(row[support_col]):
                supports[f"level_{i}"] = format_float(row[support_col], asset=contract)

            if resistance_col in df.columns and not pd.isna(row[resistance_col]):
                resistances[f"level_{i}"] = format_float(
                    row[resistance_col], asset=contract
                )

        if supports:
            candle["indicators"]["supports"] = supports

        if resistances:
            candle["indicators"]["resistances"] = resistances

        formatted_data.append(candle)

    return formatted_data


def create_llm_prompt(contract, interval, limit, market_data):
    """Create a prompt for the LLM to fetch data"""

    json_example = """
{
    "trade_type": "long/short/hold",
    "entry_price": "entry price with appropriate decimal places for the asset",
    "stop_loss": "stop loss price with appropriate decimal places",
    "take_profit": "take profit price with appropriate decimal places",
    "leverage": "leverage used as integer between 10-20",
    "risk_reward_ratio": "risk reward ratio",
    "reasoning": "reasoning for the trade"
}
"""

    prompt = f"""Suppose you are an expert trader and you want to analyze the market data for a specific contract.
You choose to analyze the contract: {contract} with an interval of {interval} and a limit of {limit} candles.
Your main aim is to analyze the market data and provide insights to make informed trading decisions.

IMPORTANT GUIDELINES:
1. Use the exact decimal precision appropriate for the {contract} asset (for example, Bitcoin might use 1 decimal place, some altcoins might need 4-6 decimal places)
2. If you are confident in the trade, SET THE STOP LOSS WITH ENOUGH BUFFER to handle normal volatility
3. Your take profit must be different from entry price and aim for 10% - 20% profit with the leverage used for quick trades (calculate profit with the leverage and give reasonable take profit price)
4. Trade type must be either "long", "short", or "hold" based on your analysis
5. Leverage should be between 10x and 20x, with lower leverage for higher risk trades

You should analyze the given market data and provide the following information in json format and JSON format only.
Here is a simple example of the expected output:
{json_example}

You will only provide the json output and nothing else.

Here's the detailed information for your decision making:
{json.dumps(market_data, indent=2)}
ONLY GIVE TRADE IF YOU ARE SURE AND YOUR TAKE PROFIT AND STOP LOSS ARE REASONABLE.
OUR AIM IS TO MAKE PROFIT AND NOT TO LOSE MONEY.
MAKE SURE YOU WISELY CHOOSE THE TRADE TYPE, ENTRY PRICE, STOP LOSS, TAKE PROFIT, LEVERAGE, RISK REWARD RATIO AND REASONING.
"""
    return prompt


def create_enhanced_llm_prompt(contract, main_interval, limit, market_data):
    """Create an enhanced prompt for the LLM with multi-timeframe data and time estimation request"""

    json_example = """
{
    "trade_type": "long/short/hold",
    "entry_price": "entry price with appropriate decimal places for the asset",
    "stop_loss": "stop loss price with appropriate decimal places",
    "take_profit": "take profit price with appropriate decimal places",
    "leverage": "leverage used as integer between 10-20",
    "risk_reward_ratio": "risk reward ratio",
    "time_to_target_estimate": "estimated time in minutes/hours to reach target",
    "reassessment_time": "how many minutes/hours until this analysis should be reconsidered",
    "reasoning": "detailed reasoning for the trade including multi-timeframe analysis"
}
"""

    timeframes_available = list(market_data["analysis"].keys())
    timeframes_str = ", ".join(timeframes_available)

    prompt = f"""Suppose you are an expert cryptocurrency trader analyzing market data for {contract} across multiple timeframes ({timeframes_str}).
Your primary timeframe for analysis is {main_interval}, but you also consider the smaller timeframes for confirmation.

IMPORTANT GUIDELINES:
1. Use the exact decimal precision appropriate for the {contract} asset (for example, Bitcoin might use 1 decimal place, some altcoins might need 4-6 decimal places)
2. Set the stop loss with ENOUGH BUFFER to handle normal volatility (check the volatility metrics!)
3. Your take profit must be different from entry price and aim for 1-5% profit with leverage for quick trades
4. Trade type must be either "long", "short", or "hold" based on your comprehensive analysis
5. Leverage should be between 10x and 20x, with lower leverage for higher risk trades
6. Estimate how long (in minutes/hours) you expect it will take to reach the take profit target
7. Specify how soon (in minutes/hours) this analysis should be reassessed if the trade is not executed

You should analyze the given market data and provide the following information in JSON format and JSON format only.
The expected output format is:
{json_example}

Here's the detailed information for your decision making:
{json.dumps(market_data, indent=2)}

ONLY RECOMMEND A TRADE IF YOU ARE CONFIDENT BASED ON MULTI-TIMEFRAME ANALYSIS.
ENSURE YOUR STOP LOSS AND TAKE PROFIT LEVELS ARE REASONABLE AND ACCOUNT FOR VOLATILITY.
YOU MUST ESTIMATE THE TIME TO REACH TARGET AND WHEN REASSESSMENT IS NEEDED.
PROVIDE YOUR RESPONSE AS VALID JSON WITH NO CONTROL CHARACTERS.
"""
    return prompt


def chat_with_llm(gemini_api_key, prompt):
    """Chat with LLM using Google's Generative AI"""
    # Configure the genai library with your API key
    genai.configure(api_key=gemini_api_key)

    try:
        # For newer versions of the library, use generation_config
        model = genai.GenerativeModel("gemini-2.0-flash")
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        print(f"Error communicating with Google Generative AI: {e}")
        return None


def clean_llm_response(response):
    """Clean up the LLM response to extract valid JSON with minimal modifications"""
    if not response:
        return None

    # Remove markdown code block indicators
    response = response.strip()
    response = response.replace("```json", "").replace("```", "")

    # Remove any leading/trailing whitespace and newlines
    response = response.strip()

    try:
        # First attempt: direct JSON parsing
        try:
            json_data = json.loads(response)
        except json.JSONDecodeError:
            # Second attempt: sanitize the response more aggressively
            # Replace all control characters and normalize newlines
            import re

            # Replace actual newlines with escaped newlines in the string
            response = response.replace("\n", "\\n")

            # Remove any remaining control characters that might cause issues
            response = re.sub(r"[\x00-\x1F\x7F]", "", response)

            # Try to parse the sanitized response
            try:
                json_data = json.loads(response)
            except json.JSONDecodeError as e:
                # Final attempt: try using a more lenient approach
                print(f"Second attempt also failed: {e}")
                print("Attempting alternative parsing method...")

                # Convert the response to an equivalent Python object structure
                # This is a last resort and potentially unsafe for production
                import ast

                try:
                    # Replace JSON-style strings with Python-style
                    py_response = (
                        response.replace("null", "None")
                        .replace("true", "True")
                        .replace("false", "False")
                    )
                    py_data = ast.literal_eval(py_response)
                    json_data = py_data
                except (SyntaxError, ValueError) as e:
                    print(f"All parsing attempts failed: {e}")
                    return None

        # Minimal validation - check only for missing required fields
        required_fields = [
            "trade_type",
            "entry_price",
            "stop_loss",
            "take_profit",
            "leverage",
            "risk_reward_ratio",
            "reasoning",
        ]

        missing_fields = []
        for field in required_fields:
            if field not in json_data:
                missing_fields.append(field)

        if missing_fields:
            print(
                f"WARNING: Missing fields in LLM response: {', '.join(missing_fields)}"
            )

        # Check type of leverage - ensure it's an integer
        if "leverage" in json_data and not isinstance(json_data["leverage"], int):
            try:
                json_data["leverage"] = int(json_data["leverage"])
            except (ValueError, TypeError):
                print(
                    f"WARNING: Could not convert leverage to integer: {json_data['leverage']}"
                )

        # Keep the original LLM response (minimizing modifications)
        return json_data

    except Exception as e:
        print(f"Unexpected error during JSON parsing: {e}")
        print(f"Response was: {response}")
        return None


def process_trade_recommendation(logger, api_config, market_data, trade_recommendation):
    """
    Process trade recommendation and execute if conditions are met
    """
    # Generate a unique ID for this trade analysis
    trade_id = str(uuid.uuid4())
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Create log data structure
    log_data = {
        "trade_id": trade_id,
        "timestamp": timestamp,
        "market_data": market_data,
        "trade_recommendation": trade_recommendation,
        "execution": {"status": "no_execution", "reason": "Default - not executed"},
    }

    # Check if this is a valid trade
    trade_type = trade_recommendation.get("trade_type")

    # Parse risk-reward ratio which might be in format "1:1.75" or just a number
    risk_reward_str = trade_recommendation.get("risk_reward_ratio", "0")
    try:
        # First try direct conversion
        risk_reward = float(risk_reward_str)
    except ValueError:
        # If it fails, try to parse it as a ratio (e.g., "1:1.75")
        try:
            if ":" in risk_reward_str:
                parts = risk_reward_str.split(":")
                if len(parts) == 2:
                    # Convert "1:1.75" to 1.75 by dividing the second part by the first
                    risk_reward = float(parts[1]) / float(parts[0])
                else:
                    risk_reward = 0
            else:
                # If no recognized format, default to 0
                risk_reward = 0
        except (ValueError, ZeroDivisionError):
            logger.error(f"Could not parse risk-reward ratio: {risk_reward_str}")
            risk_reward = 0

    logger.info(
        f"Parsed risk-reward ratio: {risk_reward} from value: {risk_reward_str}"
    )

    if trade_type == "hold":
        log_data["execution"]["reason"] = "No trade - recommendation is to hold"
        logger.info("Trade recommendation is to hold, no action taken")
    elif risk_reward < RISK_REWARD_THRESHOLD:
        log_data["execution"][
            "reason"
        ] = f"Risk/reward ratio ({risk_reward}) below threshold {RISK_REWARD_THRESHOLD}"
        logger.info(
            f"Risk/reward ratio {risk_reward} is below threshold of {RISK_REWARD_THRESHOLD}, no action taken"
        )
    else:
        # Conditions met, execute the trade
        logger.info(
            f"Executing {trade_type} trade with risk/reward ratio of {risk_reward}"
        )

        try:
            # Extract contract from market data
            contract = market_data.get("contract", "")

            # Execute the trade using the futures module
            execution_result = create_leveraged_futures_order(
                logger=logger,
                api_key=api_config["api_key"],
                api_secret=api_config["api_secret"],
                host_used=api_config["host_used"],
                settle=contract.split("_")[1].lower() if "_" in contract else "usdt",
                contract=contract,
                direction=trade_type.lower(),
                leverage=str(trade_recommendation.get("leverage", "10")),
                take_profit=trade_recommendation.get("take_profit"),
                stop_loss=trade_recommendation.get("stop_loss"),
            )

            # Update log with execution results
            if execution_result.get("success", False):
                log_data["execution"] = {
                    "status": "executed",
                    "order_id": execution_result.get("order_id"),
                    "details": execution_result,
                }
                logger.info(
                    f"Trade executed successfully with order ID: {execution_result.get('order_id')}"
                )
            else:
                log_data["execution"] = {
                    "status": "failed",
                    "reason": execution_result.get("error", "Unknown error"),
                    "details": execution_result,
                }
                logger.error(f"Trade execution failed: {execution_result.get('error')}")

        except Exception as e:
            log_data["execution"] = {"status": "error", "reason": str(e)}
            logger.error(f"Error executing trade: {e}")

    # Save log data to file
    save_trade_log(log_data, trade_id)

    return log_data


def save_trade_log(log_data, trade_id):
    """Save trade log data to a JSON file with unique ID"""
    try:
        # Create logs directory if it doesn't exist
        os.makedirs("logs", exist_ok=True)

        # Timestamp for filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"logs/trade_{timestamp}_{trade_id[:8]}.json"

        # Write log to file
        with open(filename, "w") as f:
            json.dump(log_data, indent=2, fp=f)

        print(f"Trade log saved to {filename}")
        return True
    except Exception as e:
        print(f"Error saving trade log: {e}")
        return False


def main():
    """Main function to execute the program with multi-timeframe analysis"""
    parser = argparse.ArgumentParser(
        description="Fetch and analyze cryptocurrency market data across multiple timeframes"
    )
    parser.add_argument(
        "-c",
        "--contract",
        default="BTC_USDT",
        help="Contract to analyze, e.g. BTC_USDT",
    )
    parser.add_argument(
        "-i",
        "--interval",
        default="1h",
        help="Main candle interval, e.g. 5m, 15m, 1h, 4h, 1d",
    )
    parser.add_argument(
        "-l",
        "--limit",
        type=int,
        default=100,
        help="Number of candles to retrieve (max 1000)",
    )
    parser.add_argument("-s", "--settle", default="usdt", help="Settlement currency")
    parser.add_argument("-o", "--output", help="Output CSV file path")
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="Enable verbose logging"
    )
    parser.add_argument(
        "--execute", action="store_true", help="Execute trades if conditions are met"
    )

    args = parser.parse_args()

    # Setup logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logger = setup_logging(log_level)

    # Load API configuration
    api_config = load_api_config()

    # Fetch multi-timeframe market data
    timeframe_data = fetch_multi_timeframe_data(
        logger, api_config, args.contract, args.settle, args.interval, args.limit
    )

    if timeframe_data and args.interval in timeframe_data:
        main_df = timeframe_data[args.interval]

        # Save to CSV if requested
        if args.output and main_df is not None:
            if save_data_to_csv(main_df, args.output):
                logger.info(f"Main interval data saved to {args.output}")

        # Analyze data for each timeframe
        analysis_by_timeframe = {}
        recent_data_by_timeframe = {}

        for interval, df in timeframe_data.items():
            analysis_by_timeframe[interval] = analyze_market_data(
                df, contract=args.contract
            )
            recent_data_by_timeframe[interval] = format_market_data_for_llm(
                df, max_rows=min(20, args.limit), contract=args.contract
            )

        # Prepare output with multi-timeframe data
        market_data = {
            "primary_timeframe": args.interval,
            "contract": args.contract,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "analysis": analysis_by_timeframe,
            "recent_data": recent_data_by_timeframe,
        }

        llm_prompt = create_enhanced_llm_prompt(
            args.contract, args.interval, args.limit, market_data
        )
        llm_response = chat_with_llm(
            gemini_api_key=api_config["gemini_api_key"], prompt=llm_prompt
        )

        if llm_response:
            # Clean and parse the response
            trade_recommendation = clean_llm_response(llm_response)

            if trade_recommendation:
                logger.info("Successfully received trade recommendation")

                # Format the output for console
                final_output = {
                    "market_analysis": analysis_by_timeframe[args.interval],
                    "trade_recommendation": trade_recommendation,
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                }

                # Print formatted JSON
                print(json.dumps(final_output, indent=2))

                # Process trade recommendation if execution is enabled
                if args.execute:
                    logger.info(
                        "Execution flag is set, processing trade recommendation"
                    )
                    execution_result = process_trade_recommendation(
                        logger, api_config, market_data, trade_recommendation
                    )
                    if (
                        execution_result.get("execution", {}).get("status")
                        != "executed"
                    ):
                        logger.info(
                            f"Trade not executed: {execution_result.get('execution', {}).get('reason')}"
                        )
                else:
                    logger.info("Execution flag not set, skipping trade execution")
                    # Still save the analysis without execution
                    log_data = {
                        "trade_id": str(uuid.uuid4()),
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "market_data": market_data,
                        "trade_recommendation": trade_recommendation,
                        "execution": {
                            "status": "no_execution",
                            "reason": "Execution flag not set",
                        },
                    }
                    save_trade_log(log_data, log_data["trade_id"])
            else:
                logger.error("Failed to parse LLM response as JSON")
                print("Raw response:")
                print(llm_response)
        else:
            logger.error("No response received from LLM")
    else:
        logger.error("Failed to retrieve market data")


if __name__ == "__main__":
    main()
