import logging
import pandas as pd
import numpy as np
import time
from decimal import Decimal as D, ROUND_UP, getcontext

from gate_api import (
    ApiClient,
    Configuration,
    FuturesApi,
    FuturesOrder,
    WalletApi,
    SpotApi,
)
from gate_api.exceptions import GateApiException


def get_historical_data_with_specific_indicators(
    logger=logging.getLogger(__name__), **kwargs
):
    """
    Get historical candlestick data with specific technical indicators (SRL, SAR, VOL, MACD, RSI)

    :param kwargs: Dictionary containing:
        - api_key: API key for authentication
        - api_secret: API secret for authentication
        - host_used: API host URL
        - settle: Settlement currency (e.g., "usdt") for futures data
        - contract: Contract name (e.g., "BTC_USDT")
        - interval: Time interval (e.g., "1m", "5m", "15m", "30m", "1h", "4h", "1d", etc.)
        - limit: Number of candles to retrieve (max 1000)
        - from_time: Start time in seconds (optional)
        - to_time: End time in seconds (optional)
    :return: DataFrame with candlestick data and indicators
    """
    logger.debug(
        f"Retrieving {kwargs.get('interval', '5m')} historical data for "
        f"{kwargs.get('contract', 'unknown')} with specific indicators"
    )

    # Initialize API client
    config = Configuration(
        key=kwargs["api_key"], secret=kwargs["api_secret"], host=kwargs["host_used"]
    )

    # Map interval strings to Gate.io API interval values
    # Gate.io API expects:
    # '10s', '1m', '5m', '15m', '30m', '1h', '4h', '8h', '1d', '7d', etc.
    # NOT the seconds values
    interval = kwargs.get("interval", "5m")

    limit = min(kwargs.get("limit", 100), 1000)  # API max is 1000

    # Get candlestick data
    try:
        futures_api = FuturesApi(ApiClient(config))
        settle = kwargs["settle"]
        contract = kwargs["contract"]

        # Prepare parameters
        params = {
            "contract": contract,
            "limit": limit,
            "interval": interval,  # Pass the interval string directly
        }

        # Add optional time parameters
        if "from_time" in kwargs:
            params["from"] = int(kwargs["from_time"])
        if "to_time" in kwargs:
            params["to"] = int(kwargs["to_time"])

        # Get candlestick data
        logger.debug(f"Requesting candlestick data with params: {params}")
        candles = futures_api.list_futures_candlesticks(settle, **params)

        # Create DataFrame
        df = pd.DataFrame(
            [
                {
                    "timestamp": int(c.t),
                    "time": pd.to_datetime(int(c.t), unit="s"),
                    "open": float(c.o),
                    "high": float(c.h),
                    "low": float(c.l),
                    "close": float(c.c),
                    "volume": float(c.v),
                }
                for c in candles
            ]
        )

        # Sort by timestamp (ascending)
        df = df.sort_values("timestamp")

        # Calculate specific indicators

        # 1. Volume (VOL) - Already available in the data
        df["VOL"] = df["volume"]

        # 2. RSI (Relative Strength Index)
        def calculate_rsi(data, period=14):
            delta = data.diff()
            gain = delta.where(delta > 0, 0)
            loss = -delta.where(delta < 0, 0)

            avg_gain = gain.rolling(window=period).mean()
            avg_loss = loss.rolling(window=period).mean()

            rs = avg_gain / avg_loss
            return 100 - (100 / (1 + rs))

        df["RSI"] = calculate_rsi(df["close"], 14)

        # 3. MACD (Moving Average Convergence Divergence)
        def calculate_macd(data, fast=12, slow=26, signal=9):
            ema_fast = data.ewm(span=fast, adjust=False).mean()
            ema_slow = data.ewm(span=slow, adjust=False).mean()
            macd_line = ema_fast - ema_slow
            signal_line = macd_line.ewm(span=signal, adjust=False).mean()
            histogram = macd_line - signal_line
            return pd.DataFrame(
                {
                    "MACD_LINE": macd_line,
                    "MACD_SIGNAL": signal_line,
                    "MACD_HIST": histogram,
                }
            )

        macd_data = calculate_macd(df["close"])
        df = pd.concat([df, macd_data], axis=1)

        # 4. SAR (Parabolic Stop and Reverse)
        def calculate_psar(high, low, close, acceleration=0.02, maximum=0.2):
            length = len(high)
            psar = np.zeros(length)
            psarbull = [None] * length  # Bullish trend SAR
            psarbear = [None] * length  # Bearish trend SAR
            bull = True
            af = acceleration
            ep = low[0]
            hp = high[0]
            lp = low[0]

            for i in range(2, length):
                if bull:
                    psar[i] = psar[i - 1] + af * (hp - psar[i - 1])
                else:
                    psar[i] = psar[i - 1] + af * (lp - psar[i - 1])

                reverse = False

                if bull:
                    if low[i] < psar[i]:
                        bull = False
                        reverse = True
                        psar[i] = hp
                        lp = low[i]
                        af = acceleration
                else:
                    if high[i] > psar[i]:
                        bull = True
                        reverse = True
                        psar[i] = lp
                        hp = high[i]
                        af = acceleration

                if not reverse:
                    if bull:
                        if high[i] > hp:
                            hp = high[i]
                            af = min(af + acceleration, maximum)
                        if low[i - 1] < psar[i]:
                            psar[i] = low[i - 1]
                        if low[i - 2] < psar[i]:
                            psar[i] = low[i - 2]
                    else:
                        if low[i] < lp:
                            lp = low[i]
                            af = min(af + acceleration, maximum)
                        if high[i - 1] > psar[i]:
                            psar[i] = high[i - 1]
                        if high[i - 2] > psar[i]:
                            psar[i] = high[i - 2]

                if bull:
                    psarbull[i] = psar[i]
                else:
                    psarbear[i] = psar[i]

            return (
                pd.Series(psar, index=high.index),
                pd.Series(psarbull, index=high.index),
                pd.Series(psarbear, index=high.index),
            )

        psar, psarbull, psarbear = calculate_psar(df["high"], df["low"], df["close"])
        df["SAR"] = psar
        df["SAR_BULL"] = psarbull
        df["SAR_BEAR"] = psarbear

        # 5. SRL (Support Resistance Lines)
        def identify_support_resistance(data, window=5):
            pivots = []
            supports = []
            resistances = []

            # Find pivot points (local highs and lows)
            for i in range(window, len(data) - window):
                if all(
                    data["high"][i] > data["high"][i - j] for j in range(1, window + 1)
                ) and all(
                    data["high"][i] > data["high"][i + j] for j in range(1, window + 1)
                ):
                    pivots.append((i, data["high"][i], "resistance"))
                    resistances.append(data["high"][i])
                if all(
                    data["low"][i] < data["low"][i - j] for j in range(1, window + 1)
                ) and all(
                    data["low"][i] < data["low"][i + j] for j in range(1, window + 1)
                ):
                    pivots.append((i, data["low"][i], "support"))
                    supports.append(data["low"][i])

            # Create DataFrame columns for supports and resistances
            sr_data = pd.DataFrame(index=data.index)

            # Get the 3 most recent supports and resistances
            recent_supports = sorted(supports, reverse=True)[:3] if supports else []
            recent_resistances = sorted(resistances)[:3] if resistances else []

            # Add to DataFrame
            for i, val in enumerate(recent_supports):
                sr_data[f"SUPPORT_{i+1}"] = val

            for i, val in enumerate(recent_resistances):
                sr_data[f"RESISTANCE_{i+1}"] = val

            return sr_data

        sr_lines = identify_support_resistance(df)
        df = pd.concat([df, sr_lines], axis=1)

        return {"success": True, "data": df, "interval": interval, "contract": contract}

    except GateApiException as ex:
        logger.error(f"Error retrieving historical data: {ex}")
        return {"success": False, "error": str(ex)}

    except Exception as ex:
        logger.error(f"Unexpected error: {ex}")
        return {"success": False, "error": str(ex)}
