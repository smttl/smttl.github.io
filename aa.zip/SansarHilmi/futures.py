import logging
import time
from decimal import Decimal as D, ROUND_UP, getcontext

from gate_api import (
    ApiClient,
    Configuration,
    FuturesApi,
    FuturesOrder,
)
from gate_api.exceptions import GateApiException


def create_leveraged_futures_order(logger=logging.getLogger(__name__), **kwargs):
    """
    Create a futures order using 10% of available balance with take profit and stop loss

    :param logger: Logger object
    :param kwargs: Dictionary containing:
        - api_key: API key for authentication
        - api_secret: API secret for authentication
        - host_used: API host URL
        - settle: Settlement currency (e.g., "usdt")
        - contract: Contract name (e.g., "BTC_USDT")
        - direction: "long" or "short"
        - leverage: Leverage amount as string (e.g., "3")
        - take_profit: Optional take profit price
        - stop_loss: Optional stop loss price
    :return: Dictionary with order details and status
    """
    # Initialize API client
    try:
        config = Configuration(
            key=kwargs["api_key"], secret=kwargs["api_secret"], host=kwargs["host_used"]
        )
        api = FuturesApi(ApiClient(config))

        # Set precision for calculations
        getcontext().prec = 8
        getcontext().rounding = ROUND_UP

        # Extract key parameters
        settle = kwargs["settle"]
        contract = kwargs["contract"]
        leverage = kwargs["leverage"]
        direction = kwargs["direction"].lower()
        take_profit = kwargs.get("take_profit")
        stop_loss = kwargs.get("stop_loss")

        logger.info(
            f"Preparing {direction} order for {contract} with leverage {leverage}x"
        )

        # Step 1: Set margin mode to cross BEFORE setting leverage
        try:
            # First check account mode
            account_mode = api.get_futures_account_book(settle, limit=1)
            logger.info(f"Current account mode: {account_mode}")

            # Attempt to set cross margin mode
            try:
                api.set_dual_mode(settle, dual_mode=False)
                logger.info("Position margin mode set to cross (dual_mode=False)")
            except GateApiException as ex:
                if getattr(ex, "label", "") != "NO_CHANGE":
                    logger.warning(f"Note: {ex}. Continuing with existing margin mode.")
        except Exception as ex:
            logger.warning(f"Could not verify/set margin mode: {ex}")

        # Step 2: Set leverage
        try:
            api.update_position_leverage(settle, contract, leverage)
            logger.info(f"Position leverage set to {leverage}x")
        except GateApiException as ex:
            if "POSITION_NOT_FOUND" in str(ex):
                logger.info(
                    f"No position found yet, leverage will be applied to new position"
                )
            else:
                logger.error(f"Error setting leverage: {ex}")
                return {"success": False, "error": f"Failed to set leverage: {str(ex)}"}

        # Step 3: Get account balance
        account = api.list_futures_accounts(settle)
        available_balance = D(account.available)
        trade_amount = available_balance * D("0.1")  # Use 10% of available balance
        logger.info(
            f"Available balance: {available_balance} {settle}, using {trade_amount} for trade"
        )

        # Step 4: Check for existing positions
        positions = api.list_positions(settle)
        existing_position = None

        for pos in positions:
            if pos.contract == contract:
                existing_position = pos
                logger.info(
                    f"Found existing position for {contract}: size={pos.size}, entry_price={pos.entry_price}"
                )

                if (direction == "long" and pos.size > 0) or (
                    direction == "short" and pos.size < 0
                ):
                    logger.warning(
                        f"Position already exists in the same direction: {pos.size}"
                    )
                break

        # Step 5: Get contract information and calculate order size
        contract_info = api.get_futures_contract(settle, contract)
        tickers = api.list_futures_tickers(settle, contract=contract)

        if not tickers or len(tickers) < 1:
            return {"success": False, "error": "Could not retrieve market price"}

        market_price = D(tickers[0].last)
        logger.info(f"Current {contract} price: {market_price}")

        # Calculate proper order size based on available balance
        quanto_multiplier = D(contract_info.quanto_multiplier or "1")
        size_per_contract = market_price * quanto_multiplier / D(leverage)

        # Calculate contracts we can trade with 10% of balance
        max_contracts = int((trade_amount / size_per_contract).to_integral_exact())
        min_size = D(contract_info.order_size_min or "1")
        order_size = max(max_contracts, int(min_size))

        # Adjust direction
        if direction == "short":
            order_size = -order_size

        logger.info(f"Creating {direction} order with size: {order_size}")

        # Step 6: Format order price correctly - limit to proper decimal precision
        # The error was "price digit is greater than 12"
        price_increment = D(contract_info.order_price_round or "0.001")

        # Format price to match the contract's required precision
        def format_price(price, increment):
            # Convert to Decimal if it's not already
            if not isinstance(price, D):
                price = D(str(price))

            # Calculate how many decimal places to keep
            decimal_places = 0
            temp_increment = increment
            while temp_increment < 1:
                decimal_places += 1
                temp_increment *= 10

            # Round to the appropriate number of decimal places
            rounded_price = round(price / increment) * increment

            # Format as string with fixed decimal places
            return f"{rounded_price:.{decimal_places}f}"

        # Format prices based on direction
        if direction == "long":
            # For long, use slightly higher price (0.1% above) to ensure execution
            raw_price = float(market_price) * 1.001
            order_price = format_price(raw_price, price_increment)
        else:
            # For short, use slightly lower price (0.1% below) to ensure execution
            raw_price = float(market_price) * 0.999
            order_price = format_price(raw_price, price_increment)

        logger.info(f"Using order price: {order_price} with proper contract precision")

        # Create the order with properly formatted price
        order = FuturesOrder(
            contract=contract,
            size=order_size,
            price=order_price,  # Properly formatted limit price
            tif="gtc",  # Good-till-canceled
            reduce_only=False,
            close=False,
            iceberg=0,
        )

        # Place the order
        order_response = api.create_futures_order(settle, order)
        logger.info(
            f"Order created with ID: {order_response.id}, status: {order_response.status}"
        )

        # Step 7: Verify position was created
        time.sleep(2)  # Wait for order processing

        position_verified = False
        try:
            positions = api.list_positions(settle)
            for pos in positions:
                if pos.contract == contract:
                    if (direction == "long" and pos.size > 0) or (
                        direction == "short" and pos.size < 0
                    ):
                        logger.info(
                            f"Verified position created: size={pos.size}, entry_price={pos.entry_price}"
                        )
                        position_verified = True
                        break

            if not position_verified:
                logger.warning(
                    "Order was created but position verification failed - check exchange"
                )

        except GateApiException as ex:
            logger.error(f"Error verifying position: {ex}")

        # Step 8: Place take profit and stop loss orders with proper price formatting
        if take_profit or stop_loss:
            time.sleep(1)  # Wait to ensure position is established

            # Take profit order
            if take_profit:
                tp_price = format_price(take_profit, price_increment)
                tp_order = FuturesOrder(
                    contract=contract,
                    size=-order_size,  # Opposite direction of entry
                    price=tp_price,  # Properly formatted price
                    tif="gtc",
                    reduce_only=True,  # Ensure it only reduces the position
                )

                try:
                    tp_response = api.create_futures_order(settle, tp_order)
                    logger.info(
                        f"Take profit order placed at {tp_price} with ID: {tp_response.id}"
                    )
                except GateApiException as ex:
                    logger.error(f"Failed to place take profit order: {ex}")

            # Stop loss order
            if stop_loss:
                sl_price = format_price(stop_loss, price_increment)
                sl_order = FuturesOrder(
                    contract=contract,
                    size=-order_size,  # Opposite direction of entry
                    price=sl_price,  # Properly formatted price
                    tif="gtc",
                    reduce_only=True,  # Ensure it only reduces the position
                )

                try:
                    sl_response = api.create_futures_order(settle, sl_order)
                    logger.info(
                        f"Stop loss order placed at {sl_price} with ID: {sl_response.id}"
                    )
                except GateApiException as ex:
                    logger.error(f"Failed to place stop loss order: {ex}")

        # Return success results
        return {
            "success": True,
            "order_id": order_response.id,
            "status": order_response.status,
            "size": order_size,
            "contract": contract,
            "direction": direction,
            "entry_price": order_price,
            "take_profit": (
                take_profit
                if not take_profit
                else format_price(take_profit, price_increment)
            ),
            "stop_loss": (
                stop_loss if not stop_loss else format_price(stop_loss, price_increment)
            ),
        }

    except GateApiException as ex:
        logger.error(f"API error: {ex}")
        return {"success": False, "error": str(ex)}

    except Exception as ex:
        logger.error(f"Unexpected error: {ex}")
        return {"success": False, "error": str(ex)}
